﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using TestMk.Models;


namespace TestMk.Repository
{
    public class CustomerRepository : ICustomerRepository
    {
        private CustomerDBEntities objCustomerDBEntities;
        public CustomerRepository(CustomerDBEntities _objCustomerDBEntities)
        {
            objCustomerDBEntities = _objCustomerDBEntities;
        }
        public void Add(Customer objCutomer)
        {
            objCustomerDBEntities.Customers.Add(objCutomer);
            objCustomerDBEntities.SaveChanges();
        }

        public IEnumerable<Customer> GetAllCustomer()
        {
            return objCustomerDBEntities.Customers.ToList();
        }

        public void Update(Customer objCutomer)
        {
            objCustomerDBEntities.Customers.Add(objCutomer);
            objCustomerDBEntities.SaveChanges();
        }

        public void Delete(int CustomerId)
        {
            Customer cust = objCustomerDBEntities.Customers.Where(e => e.CustomerId == CustomerId).FirstOrDefault();
            objCustomerDBEntities.Customers.Remove(cust);
            objCustomerDBEntities.SaveChanges();
        }

        public Customer GetCustomerById(int CustomerId)
        {
           return objCustomerDBEntities.Customers.Where(e => e.CustomerId == CustomerId).FirstOrDefault();
        }
    }
}