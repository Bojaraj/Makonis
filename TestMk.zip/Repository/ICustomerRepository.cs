﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TestMk.Models;

namespace TestMk.Repository
{
    public interface ICustomerRepository
    {
        void Add(Customer objCutomer);
        IEnumerable<Customer> GetAllCustomer();
        void Update(Customer objCutomer);
        void Delete(int CustomerId);
        Customer GetCustomerById(int CustomerId);
    }
}
